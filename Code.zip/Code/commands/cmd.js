module.exports = {
    name: 'cmd',
    description: "cmd",
    execute(message, args){
        message.channel.send('cant hack me loser')
    }
}